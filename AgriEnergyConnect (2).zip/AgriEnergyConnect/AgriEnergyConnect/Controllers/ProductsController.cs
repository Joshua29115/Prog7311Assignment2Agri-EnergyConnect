﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using AgriEnergyConnect.Data;
using AgriEnergyConnect.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
// Code Attribution: The general structure and logic for this controller, including the use of Entity Framework Core for CRUD operations, were influenced by Griffiths (2019).
namespace AgriEnergyConnect.Controllers
{
// Controller for managing agricultural products, accessible to authenticated users. Farmers can create and delete products, while employees can view them.
    [Authorize]
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ProductsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // Displays a filtered list of products based on category, date range, and user role (farmers see only their products, employees see all).
        public IActionResult Index(string category, DateTime? startDate, DateTime? endDate)
        {
            var userId = _userManager.GetUserId(User);
            var isEmployee = User.IsInRole("Employee");

            var products = _context.Products
                .Include(p => p.Farmer)
                .AsQueryable();

            if (!isEmployee)
            {
                products = products.Where(p => p.Farmer.UserId == userId);
            }

            if (!string.IsNullOrEmpty(category))
            {
                products = products.Where(p => p.Category == category);
            }

            if (startDate.HasValue)
            {
                products = products.Where(p => p.ProductionDate >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                products = products.Where(p => p.ProductionDate <= endDate.Value);
            }

            ViewBag.Categories = _context.Products.Select(p => p.Category).Distinct().ToList();
            return View(products.ToList());
        }

        [Authorize(Roles = "Farmer")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Farmer")]
        public IActionResult Create([Bind("ProductId,FarmerId,Name,Category,ProductionDate")] Product product)
        {
            // Clear any validation errors related to Farmer
            if (ModelState.ContainsKey("Farmer"))
            {
                ModelState.Remove("Farmer");
            }

            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var farmer = _context.Farmers.FirstOrDefault(f => f.UserId == userId);
                if (farmer != null)
                {
                    product.FarmerId = farmer.FarmerId;
                    _context.Add(product);
                    _context.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Farmer not found for the current user.");
                }
            }
            else
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                ModelState.AddModelError("", "Validation failed: " + string.Join(", ", errors));
            }
            return View(product);
        }

        // POST: Products/Delete
        [Authorize(Roles = "Farmer")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}