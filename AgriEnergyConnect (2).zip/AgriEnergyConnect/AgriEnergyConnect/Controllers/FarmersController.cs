﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using AgriEnergyConnect.Data;
using AgriEnergyConnect.Models;
using Microsoft.EntityFrameworkCore;
// Code Attribution: The general structure and logic for this controller, including the use of Entity Framework Core for CRUD operations, were influenced by Griffiths (2019).
// Controller for managing farmer profiles, accessible only to employees. Handles CRUD operations for farmers.
namespace AgriEnergyConnect.Controllers
{
    [Authorize(Roles = "Employee")]
    public class FarmersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FarmersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Displays a list of all farmers in the database.
        public IActionResult Index()
        {
            var farmers = _context.Farmers.ToList();
            return View(farmers);
        }

        public IActionResult Create()
        {
            return View();
        }

        // Handles the submission of a new farmer profile, validates input, and saves to the database.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("FarmerId,UserId,Name,Email,Phone,Address")] Farmer farmer)
        {
            System.Diagnostics.Debug.WriteLine("Create action called with farmer: " + (farmer != null ? farmer.Name : "null"));

            // Clear any validation errors related to Products
            if (ModelState.ContainsKey("Products"))
            {
                ModelState.Remove("Products");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(farmer);
                    _context.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error saving farmer: {ex.Message}");
                    if (ex.InnerException != null)
                    {
                        ModelState.AddModelError("", $"Inner exception: {ex.InnerException.Message}");
                    }
                }
            }
            else
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                ModelState.AddModelError("", "Validation failed: " + string.Join(", ", errors));
            }
            return View(farmer);
        }
        // Retrieves and displays details of a specific farmer by ID, returning NotFound if the farmer doesn't exist.
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farmer = await _context.Farmers
                .FirstOrDefaultAsync(m => m.FarmerId == id);

            if (farmer == null)
            {
                return NotFound();
            }

            return View(farmer);
        }
    }
}