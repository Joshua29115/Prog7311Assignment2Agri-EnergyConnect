using System.Diagnostics;
using AgriEnergyConnect.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
// Code Attribution: The general structure and logic for this controller, including the use of Entity Framework Core for CRUD operations, were influenced by Griffiths (2019).
namespace AgriEnergyConnect.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Displays the homepage, redirects unauthenticated users to the login page, and sets the user's role in ViewBag.
        [AllowAnonymous]
        public IActionResult Index()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return Redirect("/Identity/Account/Login");
            }

            if (User.Identity.IsAuthenticated)
            {
                ViewBag.UserRoles = User.IsInRole("Farmer") ? "Farmer" : User.IsInRole("Employee") ? "Employee" : "No Role";
            }
            else
            {
                ViewBag.UserRoles = "Not Logged In";
            }
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        // Handles error display with a response cache setting to prevent caching, showing the request ID for debugging.
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}