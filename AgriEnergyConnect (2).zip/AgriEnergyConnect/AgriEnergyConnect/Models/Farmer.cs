﻿using System.ComponentModel.DataAnnotations;
// Code Attribution: The general structure and logic for this controller, including the use of Entity Framework Core for CRUD operations, were influenced by Griffiths (2019).
namespace AgriEnergyConnect.Models
{
    public class Farmer
    {
        public int FarmerId { get; set; }

        [Required(ErrorMessage = "UserId is required")]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; }

        [Phone]
        public string Phone { get; set; }

        [StringLength(200)]
        public string Address { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}