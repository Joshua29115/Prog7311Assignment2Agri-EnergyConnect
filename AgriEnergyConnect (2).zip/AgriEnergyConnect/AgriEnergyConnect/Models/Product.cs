﻿using System.ComponentModel.DataAnnotations;
// Code Attribution: The general structure and logic for this controller, including the use of Entity Framework Core for CRUD operations, were influenced by Griffiths (2019).
namespace AgriEnergyConnect.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public int FarmerId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Category is required")]
        [StringLength(50)]
        public string Category { get; set; }

        [Required(ErrorMessage = "Production Date is required")]
        public DateTime ProductionDate { get; set; }

        public virtual Farmer Farmer { get; set; }
    }
}